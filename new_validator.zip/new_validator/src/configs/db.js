const mongoose = require("mongoose");

module.exports = () => {
  return mongoose.connect(
    "mongodb+srv://rupesh:rupesh123@cluster0.f9r1r.mongodb.net/u4c3?retryWrites=true&w=majority"
  );
};
