const app = require("./index");
const connect = require("./configs/db");

app.listen(2200, async function () {
  try {
    await connect();
    console.log("listening on port 2200");
  } catch (err) {
    console.error(err.message);
  }
});
